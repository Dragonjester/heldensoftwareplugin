Installation:
Die .jar Datei �ber Datei -> Importieren dem Heldentool hinzuf�gen

Den Helden im Men� ausw�hlen, dann �ber Erweiterungen das Tool starten.
Wie gewohnt bedienen :)